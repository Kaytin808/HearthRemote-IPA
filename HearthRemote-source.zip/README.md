# Hearth Remote

A private, native iOS remote for Roku and Android-based TV devices. The app is intentionally local-only: it has no accounts, analytics, ads, or cloud service.

## Supported devices

| Device | Discovery | Controls | Device setup |
|---|---|---|---|
| Roku TV / Roku player | SSDP | Roku ECP | Enable **Settings → System → Advanced system settings → Control by mobile apps → Enabled** |
| NVIDIA Shield | Bonjour/SSDP or manual IP | Android TV Remote Service v2 | Enter the six-character code shown on the TV |
| Google TV / Onn 4K | Bonjour/SSDP or manual IP | Android TV Remote Service v2 | Enter the six-character code shown on the TV |
| Fire TV / Fire Stick | SSDP/DIAL or manual IP | ADB key events | Enable **Developer Options → ADB Debugging** |

Roku works without pairing. Google/Android TV devices use the same local TLS/protobuf remote service family as the Google TV mobile remote and do not need Developer Options. Fire TV uses its ADB-over-LAN option because it does not consistently include Google's Remote Service.

## Build

This repository contains a complete Xcode project. Apple does not ship the iOS SDK/compiler for Windows, so use either Xcode on a Mac or the included manual GitHub Actions build.

### Build on a Mac

1. Copy or clone the folder to a Mac.
2. Open `TVRemote.xcodeproj`.
3. Select the **TVRemote** target, open **Signing & Capabilities**, and choose your Apple developer team.
4. Change the bundle identifier if Xcode reports that `com.personal.HearthRemote` is unavailable.
5. Build for a connected iPhone, or archive/export an IPA for Sideloadly/LiveContainer.

### Get an IPA from Windows

1. Create a private GitHub repository and push this folder to it.
2. Open the repository's **Actions** tab and select **Build unsigned IPA**.
3. Choose **Run workflow**. When it finishes, download the `HearthRemote-unsigned` artifact.
4. Extract `HearthRemote-unsigned.ipa`, then install/sign it with Sideloadly. LiveContainer compatibility depends on its current iOS/JIT/network entitlement support.

The workflow only runs when you manually request it. It compiles without signing and does not publish the app.

The first discovery attempt triggers Apple's Local Network permission prompt. Allow it or no TV can be reached.

## Google/Android TV pairing

1. Select the discovered device or add its IP as Google/Onn TV, NVIDIA Shield, or Android TV (port `6466`).
2. Press a remote button. The TV displays a six-character hexadecimal code.
3. Enter that code in Hearth Remote. The TV remembers the bundled local client certificate across launches.

## Fire TV authorization

1. Enable ADB debugging on the Fire TV and note its IP address.
2. In Hearth Remote, tap **Devices**, then **Add manually**.
3. Choose Fire TV, keep port `5555`, and connect.
4. Accept the RSA fingerprint prompt on the TV. The key remains in the iPhone Keychain.

ADB access is powerful. Only enable it on a trusted home network and disable it when you do not need the remote.

## Third-party code

Android TV Remote Service support uses the MIT-licensed [AndroidTVRemoteControl](https://github.com/odyshewroman/AndroidTVRemoteControl) Swift package. See `THIRD_PARTY_NOTICES.md`.

## Privacy

All traffic stays on the local network. Saved device names and addresses are stored in `UserDefaults`; the ADB private key is stored in the iOS Keychain.

This personal build contains a self-signed Android TV client identity so pairing survives app reinstalls. Keep the repository private. Before any public/App Store release, replace that bundled identity with per-install certificate generation and Keychain storage.
