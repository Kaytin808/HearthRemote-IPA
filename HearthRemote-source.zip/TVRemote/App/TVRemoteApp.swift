import SwiftUI

@main
struct TVRemoteApp: App {
    @StateObject private var model = RemoteViewModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .preferredColorScheme(.dark)
        }
    }
}

