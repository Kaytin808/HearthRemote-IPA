import SwiftUI

@MainActor
final class RemoteViewModel: ObservableObject {
    @Published private(set) var savedDevices: [RemoteDevice] = []
    @Published private(set) var discoveredDevices: [RemoteDevice] = []
    @Published var selectedDevice: RemoteDevice?
    @Published var isDiscovering = false
    @Published var isSending = false
    @Published var notice: Notice?
    @Published var showingDevices = false
    @Published var pairingHost: String?

    struct Notice: Identifiable, Equatable {
        enum Style: Equatable { case info, error }
        let id = UUID()
        let text: String
        let style: Style
    }

    private let discovery = DeviceDiscoveryService()
    private let roku = RokuRemoteService()
    private let androidRemote = AndroidTVRemoteService()
    private let adb = ADBClient()
    private let storageKey = "savedRemoteDevices.v1"
    private let selectedKey = "selectedRemoteDevice.v1"

    init() {
        load()
        androidRemote.pairingCodeRequested = { [weak self] host in
            Task { @MainActor in self?.pairingHost = host }
        }
    }

    var allDevices: [RemoteDevice] {
        var keyed = savedDevices.reduce(into: [String: RemoteDevice]()) { $0[$1.id] = $1 }
        for device in discoveredDevices where keyed[device.id] == nil { keyed[device.id] = device }
        return keyed.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    func scan() {
        guard !isDiscovering else { return }
        isDiscovering = true
        notice = .init(text: "Looking on your home network…", style: .info)
        Task {
            let found = await discovery.discover()
            discoveredDevices = found
            isDiscovering = false
            notice = .init(
                text: found.isEmpty ? "No devices replied. You can add one by IP address." : "Found \(found.count) device\(found.count == 1 ? "" : "s").",
                style: found.isEmpty ? .error : .info
            )
        }
    }

    func select(_ device: RemoteDevice) {
        selectedDevice = device
        if !savedDevices.contains(where: { $0.id == device.id }) {
            var saved = device
            saved.discovered = false
            savedDevices.append(saved)
        }
        persist()
        showingDevices = false
    }

    func add(_ device: RemoteDevice) {
        savedDevices.removeAll { $0.id == device.id }
        savedDevices.append(device)
        select(device)
    }

    func remove(_ device: RemoteDevice) {
        savedDevices.removeAll { $0.id == device.id }
        if selectedDevice?.id == device.id { selectedDevice = nil }
        persist()
    }

    func send(_ action: RemoteAction) {
        guard let device = selectedDevice, !isSending else { return }
        isSending = true
        let impact = UIImpactFeedbackGenerator(style: action == .select ? .medium : .light)
        impact.impactOccurred()
        Task {
            do {
                switch device.transport {
                case .roku:
                    try await roku.send(action, to: device)
                case .androidRemote:
                    try await androidRemote.send(action, to: device)
                case .adb:
                    try await adb.send(action, to: device) { [weak self] in
                        Task { @MainActor in
                            self?.notice = .init(text: "Accept the USB debugging prompt on your TV.", style: .info)
                        }
                    }
                }
            } catch {
                notice = .init(text: error.localizedDescription, style: .error)
            }
            pairingHost = nil
            isSending = false
        }
    }

    func submitPairingCode(_ code: String) {
        androidRemote.submitPairingCode(code)
    }

    func cancelPairing() {
        pairingHost = nil
        androidRemote.cancelPairing()
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let devices = try? JSONDecoder().decode([RemoteDevice].self, from: data) {
            savedDevices = devices
        }
        if let id = UserDefaults.standard.string(forKey: selectedKey) {
            selectedDevice = savedDevices.first { $0.id == id }
        } else {
            selectedDevice = savedDevices.first
        }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(savedDevices) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
        UserDefaults.standard.set(selectedDevice?.id, forKey: selectedKey)
    }
}
