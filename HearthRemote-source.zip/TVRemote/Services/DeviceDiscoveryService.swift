import Foundation
import Network
import Darwin

struct DeviceDiscoveryService {
    func discover() async -> [RemoteDevice] {
        async let ssdpReplies = SSDPSearchSession.run()
        async let bonjourDevices = BonjourSearchSession.run()
        async let scannedRokus = RokuSubnetScanner.run()
        let (replies, bonjour, rokuScan) = await (ssdpReplies, bonjourDevices, scannedRokus)
        let ssdpDevices = await withTaskGroup(of: RemoteDevice?.self) { group in
            for headers in replies {
                group.addTask { await device(from: headers) }
            }
            var devices: [String: RemoteDevice] = [:]
            for await device in group {
                if let device { devices[device.id] = device }
            }
            return devices.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        }
        let devices = (ssdpDevices + bonjour + rokuScan).reduce(into: [String: RemoteDevice]()) { result, device in
            result[device.id] = device
        }
        return devices.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private func device(from headers: [String: String]) async -> RemoteDevice? {
        guard let location = headers["location"], let url = URL(string: location), let host = url.host else { return nil }
        let identity = [headers["server"], headers["st"], headers["usn"]].compactMap { $0 }.joined(separator: " ").lowercased()
        let details = await description(at: url)
        let detailIdentity = details.values.joined(separator: " ").lowercased()
        let combined = identity + " " + detailIdentity

        if combined.contains("roku") {
            return .init(
                name: details["friendlyName"] ?? details["user-device-name"] ?? details["modelName"] ?? "Roku",
                host: host,
                port: 8060,
                kind: .roku,
                transport: .roku,
                discovered: true
            )
        }

        // DIAL/UPnP is the common discovery layer for Cast and Fire TV products.
        guard combined.contains("dial") || combined.contains("google") || combined.contains("nvidia") || combined.contains("amazon") || combined.contains("onn") || combined.contains("android") else { return nil }
        let kind: DeviceKind
        if combined.contains("nvidia") || combined.contains("shield") { kind = .shield }
        else if combined.contains("amazon") || combined.contains("firetv") || combined.contains("fire tv") { kind = .fireTV }
        else if combined.contains("google") || combined.contains("onn") || combined.contains("chromecast") { kind = .googleTV }
        else { kind = .androidTV }
        return .init(
            name: details["friendlyName"] ?? details["modelName"] ?? kind.rawValue,
            host: host,
            port: 6466,
            kind: kind,
            transport: kind == .fireTV ? .adb : .androidRemote,
            discovered: true
        )
    }

    private func description(at url: URL) async -> [String: String] {
        var request = URLRequest(url: url, timeoutInterval: 2)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let xml = String(data: data, encoding: .utf8) else { return [:] }
        let names = ["friendlyName", "modelName", "manufacturer", "user-device-name", "serialNumber"]
        var result: [String: String] = [:]
        for name in names {
            guard let start = xml.range(of: "<\(name)>", options: .caseInsensitive),
                  let end = xml.range(of: "</\(name)>", options: .caseInsensitive, range: start.upperBound..<xml.endIndex) else { continue }
            let value = String(xml[start.upperBound..<end.lowerBound])
            result[name] = value.replacingOccurrences(of: "&amp;", with: "&")
        }
        return result
    }
}

private enum RokuSubnetScanner {
    static func run() async -> [RemoteDevice] {
        guard let prefix = wifiIPv4Prefix() else { return [] }
        return await withTaskGroup(of: RemoteDevice?.self) { group in
            var next = 1
            let concurrency = 48
            for _ in 0..<concurrency {
                let host = "\(prefix).\(next)"
                next += 1
                group.addTask { await probe(host) }
            }
            var found: [RemoteDevice] = []
            while let result = await group.next() {
                if let result { found.append(result) }
                if next <= 254 {
                    let host = "\(prefix).\(next)"
                    next += 1
                    group.addTask { await probe(host) }
                }
            }
            return found
        }
    }

    private static func probe(_ host: String) async -> RemoteDevice? {
        guard let url = URL(string: "http://\(host):8060/query/device-info") else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 0.6)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let xml = String(data: data, encoding: .utf8),
              xml.localizedCaseInsensitiveContains("<device-info") else { return nil }
        let name = tag("user-device-name", in: xml) ?? tag("friendly-device-name", in: xml) ?? tag("model-name", in: xml) ?? "Roku"
        return .init(name: name, host: host, port: 8060, kind: .roku, transport: .roku, discovered: true)
    }

    private static func tag(_ name: String, in xml: String) -> String? {
        guard let start = xml.range(of: "<\(name)>", options: .caseInsensitive),
              let end = xml.range(of: "</\(name)>", options: .caseInsensitive, range: start.upperBound..<xml.endIndex) else { return nil }
        return String(xml[start.upperBound..<end.lowerBound]).replacingOccurrences(of: "&amp;", with: "&")
    }

    private static func wifiIPv4Prefix() -> String? {
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0, let first = interfaces else { return nil }
        defer { freeifaddrs(interfaces) }
        var pointer: UnsafeMutablePointer<ifaddrs>? = first
        while let interface = pointer {
            defer { pointer = interface.pointee.ifa_next }
            guard let address = interface.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET) else { continue }
            let name = String(cString: interface.pointee.ifa_name)
            guard name == "en0" || name.hasPrefix("en") else { continue }
            var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            guard getnameinfo(address, socklen_t(address.pointee.sa_len), &buffer, socklen_t(buffer.count), nil, 0, NI_NUMERICHOST) == 0 else { continue }
            let parts = String(cString: buffer).split(separator: ".")
            if parts.count == 4 { return parts.prefix(3).joined(separator: ".") }
        }
        return nil
    }
}

private final class BonjourSearchSession: NSObject, NetServiceBrowserDelegate, NetServiceDelegate {
    private var browsers: [NetServiceBrowser] = []
    private var services: [NetService] = []
    private var devices: [String: RemoteDevice] = [:]
    private var completion: (([RemoteDevice]) -> Void)?

    static func run() async -> [RemoteDevice] {
        await withCheckedContinuation { continuation in
            let session = BonjourSearchSession()
            DispatchQueue.main.async {
                session.start { continuation.resume(returning: $0) }
            }
        }
    }

    private func start(completion: @escaping ([RemoteDevice]) -> Void) {
        self.completion = completion
        for type in ["_googlecast._tcp.", "_androidtvremote2._tcp.", "_androidtvremote._tcp.", "_adb._tcp."] {
            let browser = NetServiceBrowser()
            browser.delegate = self
            browsers.append(browser)
            browser.searchForServices(ofType: type, inDomain: "local.")
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) { self.finish() }
    }

    func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
        guard completion != nil else { return }
        services.append(service)
        service.delegate = self
        service.resolve(withTimeout: 2)
    }

    func netServiceDidResolveAddress(_ sender: NetService) {
        guard let host = numericHost(from: sender.addresses ?? []) else { return }
        let identity = sender.name.lowercased()
        let kind: DeviceKind
        if identity.contains("shield") || identity.contains("nvidia") { kind = .shield }
        else if identity.contains("fire") || identity.contains("amazon") { kind = .fireTV }
        else if identity.contains("google") || identity.contains("onn") || sender.type.contains("googlecast") { kind = .googleTV }
        else { kind = .androidTV }
        let device = RemoteDevice(
            name: sender.name.isEmpty ? kind.rawValue : sender.name,
            host: host,
            port: kind == .fireTV ? 5555 : 6466,
            kind: kind,
            transport: kind == .fireTV ? .adb : .androidRemote,
            discovered: true
        )
        devices[device.id] = device
    }

    private func numericHost(from addresses: [Data]) -> String? {
        for data in addresses {
            let host: String? = data.withUnsafeBytes { rawBuffer in
                guard let base = rawBuffer.baseAddress else { return nil }
                let address = base.assumingMemoryBound(to: sockaddr.self)
                var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                let result = getnameinfo(address, socklen_t(data.count), &buffer, socklen_t(buffer.count), nil, 0, NI_NUMERICHOST)
                return result == 0 ? String(cString: buffer) : nil
            }
            if let host, !host.contains(":") { return host }
        }
        return nil
    }

    private func finish() {
        guard let completion else { return }
        self.completion = nil
        browsers.forEach {
            $0.stop()
            $0.delegate = nil
        }
        services.forEach {
            $0.stop()
            $0.delegate = nil
        }
        completion(Array(devices.values))
    }
}

private final class SSDPSearchSession {
    private let queue = DispatchQueue(label: "HearthRemote.SSDP")
    private var connections: [NWConnection] = []
    private var replies: [String: [String: String]] = [:]
    private var completion: (([[String: String]]) -> Void)?

    static func run() async -> [[String: String]] {
        await withCheckedContinuation { continuation in
            let session = SSDPSearchSession()
            session.start { continuation.resume(returning: $0) }
        }
    }

    private func start(completion: @escaping ([[String: String]]) -> Void) {
        self.completion = completion
        for searchTarget in ["roku:ecp", "urn:dial-multiscreen-org:service:dial:1", "ssdp:all"] {
            let connection = NWConnection(host: "239.255.255.250", port: 1900, using: .udp)
            connections.append(connection)
            connection.stateUpdateHandler = { state in
                if case .ready = state {
                    let request = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: \(searchTarget)\r\n\r\n"
                    connection.send(content: Data(request.utf8), completion: .contentProcessed { _ in })
                    self.receive(on: connection)
                }
            }
            connection.start(queue: queue)
        }
        queue.asyncAfter(deadline: .now() + 2.6) { self.finish() }
    }

    private func receive(on connection: NWConnection) {
        connection.receiveMessage { data, _, _, _ in
            if let data, let text = String(data: data, encoding: .utf8) {
                let headers = self.parse(text)
                if let location = headers["location"] { self.replies[location] = headers }
            }
            if self.completion != nil { self.receive(on: connection) }
        }
    }

    private func parse(_ response: String) -> [String: String] {
        var headers: [String: String] = [:]
        for line in response.components(separatedBy: .newlines) {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let key = line[..<colon].trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespacesAndNewlines)
            headers[key] = value
        }
        return headers
    }

    private func finish() {
        guard let completion else { return }
        self.completion = nil
        let values = Array(replies.values)
        connections.forEach {
            $0.stateUpdateHandler = nil
            $0.cancel()
        }
        connections.removeAll()
        completion(values)
    }
}
