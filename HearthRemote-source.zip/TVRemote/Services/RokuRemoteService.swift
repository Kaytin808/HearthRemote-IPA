import Foundation

enum RemoteServiceError: LocalizedError {
    case invalidAddress
    case rejected(Int)
    case notConnected
    case timedOut
    case protocolError(String)

    var errorDescription: String? {
        switch self {
        case .invalidAddress: return "The device address is not valid."
        case .rejected(let status): return "The device rejected the command (HTTP \(status))."
        case .notConnected: return "Could not connect to the device."
        case .timedOut: return "The device did not respond in time."
        case .protocolError(let message): return message
        }
    }
}

struct RokuRemoteService {
    func send(_ action: RemoteAction, to device: RemoteDevice) async throws {
        var components = URLComponents()
        components.scheme = "http"
        components.host = device.host
        components.port = Int(device.port)
        components.path = "/keypress/\(action.rokuKey)"
        guard let url = components.url else { throw RemoteServiceError.invalidAddress }

        var request = URLRequest(url: url, timeoutInterval: 3)
        request.httpMethod = "POST"
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw RemoteServiceError.notConnected }
        guard (200..<300).contains(http.statusCode) else { throw RemoteServiceError.rejected(http.statusCode) }
    }
}
