import Foundation
import Security

final class ADBKeyStore {
    static let shared = ADBKeyStore()
    private let keyTag = Data("com.personal.HearthRemote.adb-key".utf8)

    private init() {}

    func signature(for token: Data) throws -> Data {
        let key = try privateKey()
        var error: Unmanaged<CFError>?
        guard let signature = SecKeyCreateSignature(
            key,
            .rsaSignatureDigestPKCS1v15SHA1,
            token as CFData,
            &error
        ) as Data? else {
            if let error { throw error.takeRetainedValue() }
            throw RemoteServiceError.protocolError("Could not sign the ADB challenge.")
        }
        return signature
    }

    func adbPublicKeyPayload() throws -> Data {
        let key = try privateKey()
        guard let publicKey = SecKeyCopyPublicKey(key),
              let external = SecKeyCopyExternalRepresentation(publicKey, nil) as Data? else {
            throw RemoteServiceError.protocolError("Could not export the ADB public key.")
        }
        let modulus = try extractModulus(from: external)
        let adbKey = try encodeADBPublicKey(modulusBigEndian: modulus)
        var payload = Data(adbKey.base64EncodedString().utf8)
        payload.append(Data(" hearth-remote@iphone\0".utf8))
        return payload
    }

    private func privateKey() throws -> SecKey {
        let lookup: [CFString: Any] = [
            kSecClass: kSecClassKey,
            kSecAttrApplicationTag: keyTag,
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecReturnRef: true
        ]
        var item: CFTypeRef?
        if SecItemCopyMatching(lookup as CFDictionary, &item) == errSecSuccess,
           let item {
            return (item as! SecKey)
        }

        let attributes: [CFString: Any] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits: 2048,
            kSecPrivateKeyAttrs: [
                kSecAttrIsPermanent: true,
                kSecAttrApplicationTag: keyTag
            ]
        ]
        var error: Unmanaged<CFError>?
        guard let key = SecKeyCreateRandomKey(attributes as CFDictionary, &error) else {
            if let error { throw error.takeRetainedValue() }
            throw RemoteServiceError.protocolError("Could not create an ADB identity.")
        }
        return key
    }

    private func extractModulus(from der: Data) throws -> Data {
        let bytes = [UInt8](der)
        var cursor = 0
        while cursor < bytes.count {
            let tag = bytes[cursor]
            cursor += 1
            guard let length = readDERLength(bytes, cursor: &cursor), cursor + length <= bytes.count else { break }
            if tag == 0x02, length >= 256 {
                var integer = Array(bytes[cursor..<(cursor + length)])
                while integer.first == 0 && integer.count > 256 { integer.removeFirst() }
                guard integer.count <= 256 else { break }
                if integer.count < 256 { integer = Array(repeating: 0, count: 256 - integer.count) + integer }
                return Data(integer)
            }
            // Descend through SEQUENCE, BIT STRING, and wrapper fields instead of skipping them.
            if tag == 0x03, cursor < bytes.count, bytes[cursor] == 0 { cursor += 1 }
            else if tag != 0x30 { cursor += length }
        }
        throw RemoteServiceError.protocolError("The RSA public key format was not recognized.")
    }

    private func readDERLength(_ bytes: [UInt8], cursor: inout Int) -> Int? {
        guard cursor < bytes.count else { return nil }
        let first = Int(bytes[cursor]); cursor += 1
        if first & 0x80 == 0 { return first }
        let count = first & 0x7f
        guard count > 0, count <= 4, cursor + count <= bytes.count else { return nil }
        var result = 0
        for _ in 0..<count { result = (result << 8) | Int(bytes[cursor]); cursor += 1 }
        return result
    }

    private func encodeADBPublicKey(modulusBigEndian: Data) throws -> Data {
        guard modulusBigEndian.count == 256 else {
            throw RemoteServiceError.protocolError("ADB requires a 2048-bit RSA key.")
        }
        let reversed = Array(modulusBigEndian.reversed())
        var modulus = [UInt32](repeating: 0, count: 64)
        for word in 0..<64 {
            let offset = word * 4
            modulus[word] = UInt32(reversed[offset])
                | UInt32(reversed[offset + 1]) << 8
                | UInt32(reversed[offset + 2]) << 16
                | UInt32(reversed[offset + 3]) << 24
        }

        var inverse: UInt32 = 1
        for _ in 0..<5 { inverse = inverse &* (2 &- modulus[0] &* inverse) }
        let n0inv = 0 &- inverse

        var rr = [UInt32](repeating: 0, count: 64)
        rr[0] = 1
        for _ in 0..<4096 { doubleModulo(&rr, modulus: modulus) }

        var output = Data()
        output.appendLittleEndian(64)
        output.appendLittleEndian(n0inv)
        modulus.forEach { output.appendLittleEndian($0) }
        rr.forEach { output.appendLittleEndian($0) }
        output.appendLittleEndian(65_537)
        return output
    }

    private func doubleModulo(_ value: inout [UInt32], modulus: [UInt32]) {
        var carry: UInt64 = 0
        for index in value.indices {
            let doubled = UInt64(value[index]) * 2 + carry
            value[index] = UInt32(truncatingIfNeeded: doubled)
            carry = doubled >> 32
        }
        if carry != 0 || compare(value, modulus) >= 0 { subtract(&value, modulus) }
    }

    private func compare(_ lhs: [UInt32], _ rhs: [UInt32]) -> Int {
        for index in lhs.indices.reversed() {
            if lhs[index] != rhs[index] { return lhs[index] < rhs[index] ? -1 : 1 }
        }
        return 0
    }

    private func subtract(_ value: inout [UInt32], _ modulus: [UInt32]) {
        var borrow: UInt64 = 0
        for index in value.indices {
            let minuend = UInt64(value[index])
            let subtrahend = UInt64(modulus[index]) + borrow
            value[index] = UInt32(truncatingIfNeeded: minuend &- subtrahend)
            borrow = minuend < subtrahend ? 1 : 0
        }
    }
}
