import Foundation

struct ADBPacket {
    static let connect: UInt32 = 0x4e584e43
    static let auth: UInt32 = 0x48545541
    static let open: UInt32 = 0x4e45504f
    static let okay: UInt32 = 0x59414b4f
    static let close: UInt32 = 0x45534c43
    static let write: UInt32 = 0x45545257

    let command: UInt32
    let argument0: UInt32
    let argument1: UInt32
    let payload: Data

    init(command: UInt32, argument0: UInt32 = 0, argument1: UInt32 = 0, payload: Data = Data()) {
        self.command = command
        self.argument0 = argument0
        self.argument1 = argument1
        self.payload = payload
    }

    var encoded: Data {
        var output = Data()
        output.appendLittleEndian(command)
        output.appendLittleEndian(argument0)
        output.appendLittleEndian(argument1)
        output.appendLittleEndian(UInt32(payload.count))
        output.appendLittleEndian(payload.reduce(UInt32(0)) { $0 &+ UInt32($1) })
        output.appendLittleEndian(command ^ UInt32.max)
        output.append(payload)
        return output
    }

    static func decode(from buffer: inout Data) throws -> ADBPacket? {
        guard buffer.count >= 24 else { return nil }
        let command = buffer.littleEndianUInt32(at: 0)
        let argument0 = buffer.littleEndianUInt32(at: 4)
        let argument1 = buffer.littleEndianUInt32(at: 8)
        let length = Int(buffer.littleEndianUInt32(at: 12))
        let checksum = buffer.littleEndianUInt32(at: 16)
        let magic = buffer.littleEndianUInt32(at: 20)
        guard length <= 1_048_576 else { throw RemoteServiceError.protocolError("ADB sent an oversized packet.") }
        guard buffer.count >= 24 + length else { return nil }
        guard magic == command ^ UInt32.max else { throw RemoteServiceError.protocolError("ADB packet header was invalid.") }
        let payload = buffer.subdata(in: 24..<(24 + length))
        let actual = payload.reduce(UInt32(0)) { $0 &+ UInt32($1) }
        guard checksum == actual else { throw RemoteServiceError.protocolError("ADB packet checksum failed.") }
        buffer.removeSubrange(0..<(24 + length))
        return .init(command: command, argument0: argument0, argument1: argument1, payload: payload)
    }
}

extension Data {
    mutating func appendLittleEndian(_ value: UInt32) {
        var little = value.littleEndian
        Swift.withUnsafeBytes(of: &little) { append(contentsOf: $0) }
    }

    func littleEndianUInt32(at offset: Int) -> UInt32 {
        let bytes = self[offset..<(offset + 4)]
        return bytes.enumerated().reduce(UInt32(0)) { result, pair in
            result | (UInt32(pair.element) << UInt32(pair.offset * 8))
        }
    }
}

