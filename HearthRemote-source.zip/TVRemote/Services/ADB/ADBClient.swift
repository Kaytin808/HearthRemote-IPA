import Foundation
import Network

final class ADBClient {
    private let queue = DispatchQueue(label: "HearthRemote.ADB")
    private let keyStore = ADBKeyStore.shared

    func send(_ action: RemoteAction, to device: RemoteDevice, authorizationRequested: @escaping () -> Void) async throws {
        try await execute("input keyevent \(action.androidKeyCode)", on: device, authorizationRequested: authorizationRequested)
    }

    private func execute(_ command: String, on device: RemoteDevice, authorizationRequested: @escaping () -> Void) async throws {
        try await withCheckedThrowingContinuation { continuation in
            let operation = ADBOperation(
                device: device,
                command: command,
                keyStore: keyStore,
                queue: queue,
                authorizationRequested: authorizationRequested
            ) { result in
                continuation.resume(with: result)
            }
            operation.start()
        }
    }
}

private final class ADBOperation {
    private let device: RemoteDevice
    private let shellCommand: String
    private let keyStore: ADBKeyStore
    private let queue: DispatchQueue
    private let authorizationRequested: () -> Void
    private let completion: (Result<Void, Error>) -> Void
    private var connection: NWConnection?
    private var buffer = Data()
    private var authChallenges = 0
    private var finished = false
    private let localID: UInt32 = 1
    private var remoteID: UInt32 = 0

    init(device: RemoteDevice, command: String, keyStore: ADBKeyStore, queue: DispatchQueue, authorizationRequested: @escaping () -> Void, completion: @escaping (Result<Void, Error>) -> Void) {
        self.device = device
        self.shellCommand = command
        self.keyStore = keyStore
        self.queue = queue
        self.authorizationRequested = authorizationRequested
        self.completion = completion
    }

    func start() {
        guard let port = NWEndpoint.Port(rawValue: device.port) else {
            return finish(.failure(RemoteServiceError.invalidAddress))
        }
        let connection = NWConnection(host: NWEndpoint.Host(device.host), port: port, using: .tcp)
        self.connection = connection
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                let banner = Data("host::features=shell_v2,cmd\0".utf8)
                self.send(.init(command: ADBPacket.connect, argument0: 0x01000000, argument1: 4096, payload: banner))
                self.receive()
            case .failed(let error): self.finish(.failure(error))
            case .cancelled where !self.finished: self.finish(.failure(RemoteServiceError.notConnected))
            default: break
            }
        }
        connection.start(queue: queue)
        queue.asyncAfter(deadline: .now() + 20) { [weak self] in
            guard let self, !self.finished else { return }
            self.finish(.failure(RemoteServiceError.timedOut))
        }
    }

    private func receive() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { data, _, complete, error in
            guard !self.finished else { return }
            if let data { self.buffer.append(data) }
            do {
                while let packet = try ADBPacket.decode(from: &self.buffer) { try self.handle(packet) }
            } catch { return self.finish(.failure(error)) }
            if let error { return self.finish(.failure(error)) }
            if complete { return self.finish(.failure(RemoteServiceError.notConnected)) }
            self.receive()
        }
    }

    private func handle(_ packet: ADBPacket) throws {
        switch packet.command {
        case ADBPacket.auth where packet.argument0 == 1:
            authChallenges += 1
            if authChallenges == 1 {
                let signature = try keyStore.signature(for: packet.payload)
                send(.init(command: ADBPacket.auth, argument0: 2, payload: signature))
            } else {
                send(.init(command: ADBPacket.auth, argument0: 3, payload: try keyStore.adbPublicKeyPayload()))
                DispatchQueue.main.async(execute: authorizationRequested)
            }
        case ADBPacket.connect:
            var destination = Data("shell:\(shellCommand)".utf8)
            destination.append(0)
            send(.init(command: ADBPacket.open, argument0: localID, payload: destination))
        case ADBPacket.okay:
            if packet.argument1 == localID { remoteID = packet.argument0 }
        case ADBPacket.write:
            remoteID = packet.argument0
            send(.init(command: ADBPacket.okay, argument0: localID, argument1: remoteID))
        case ADBPacket.close:
            let peer = packet.argument0 == 0 ? remoteID : packet.argument0
            send(.init(command: ADBPacket.close, argument0: localID, argument1: peer))
            finish(.success(()))
        default: break
        }
    }

    private func send(_ packet: ADBPacket) {
        connection?.send(content: packet.encoded, completion: .contentProcessed { [weak self] error in
            if let error { self?.finish(.failure(error)) }
        })
    }

    private func finish(_ result: Result<Void, Error>) {
        guard !finished else { return }
        finished = true
        connection?.stateUpdateHandler = nil
        connection?.cancel()
        completion(result)
    }
}
