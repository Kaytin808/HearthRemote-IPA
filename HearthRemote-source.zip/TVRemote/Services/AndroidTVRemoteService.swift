import Foundation
import Security
import AndroidTVRemoteControl

final class AndroidTVRemoteService {
    private let queue = DispatchQueue(label: "HearthRemote.AndroidTV")
    private let pairingManager: PairingManager
    private let remoteManager: RemoteManager
    private var activeHost: String?
    private var connected = false
    private var pairing = false
    private var pairedHosts = Set(UserDefaults.standard.stringArray(forKey: "androidTVPairedHosts.v1") ?? [])
    private var pending: (key: Key, completion: (Swift.Result<Void, Error>) -> Void)?
    var pairingCodeRequested: ((String) -> Void)?

    init() {
        let crypto = CryptoManager()
        crypto.clientPublicCertificate = {
            guard let url = Bundle.main.url(forResource: "HearthRemoteClient", withExtension: "der") else {
                return .Error(.createCertFromDataError)
            }
            return CertManager().getSecKey(url)
        }

        let tls = TLSManager {
            guard let url = Bundle.main.url(forResource: "HearthRemoteClient", withExtension: "p12") else {
                return .Error(.secPKCS12ImportNotSuccess)
            }
            return CertManager().cert(url, "hearth-remote-local")
        }
        tls.secTrustClosure = { trust in
            crypto.serverPublicCertificate = {
                guard let key = SecTrustCopyKey(trust) else { return .Error(.secTrustCopyKeyError) }
                return .Result(key)
            }
        }

        pairingManager = PairingManager(tls, crypto)
        remoteManager = RemoteManager(
            tls,
            CommandNetwork.DeviceInfo("Hearth Remote", "iPhone", "1.0", "com.personal.HearthRemote", "1")
        )
        installCallbacks()
    }

    func send(_ action: RemoteAction, to device: RemoteDevice) async throws {
        guard let key = Key(rawValue: UInt(action.androidKeyCode)) else {
            throw RemoteServiceError.protocolError("That button is not supported by Android TV.")
        }
        try await withCheckedThrowingContinuation { continuation in
            queue.async {
                if self.connected, self.activeHost == device.host {
                    self.remoteManager.send(KeyPress(key))
                    continuation.resume()
                    return
                }

                if self.activeHost != device.host {
                    self.remoteManager.disconnect()
                    self.pairingManager.disconnect()
                    self.connected = false
                    self.pairing = false
                    self.activeHost = device.host
                }
                self.pending = (key, { continuation.resume(with: $0) })
                if self.pairedHosts.contains(device.host) {
                    self.remoteManager.connect(device.host)
                } else {
                    self.pairing = true
                    self.pairingManager.connect(device.host, "Hearth Remote", "iPhone")
                }
            }
        }
    }

    func submitPairingCode(_ code: String) {
        queue.async { self.pairingManager.sendSecret(code.uppercased()) }
    }

    func cancelPairing() {
        queue.async {
            self.pairingManager.disconnect()
            self.remoteManager.disconnect()
            self.pairing = false
            self.connected = false
            self.complete(.failure(RemoteServiceError.protocolError("Pairing was cancelled.")))
        }
    }

    private func installCallbacks() {
        remoteManager.stateChanged = { [weak self] state in
            guard let self else { return }
            self.queue.async { self.handleRemoteState(state) }
        }
        pairingManager.stateChanged = { [weak self] state in
            guard let self else { return }
            self.queue.async { self.handlePairingState(state) }
        }
    }

    private func handleRemoteState(_ state: RemoteManager.RemoteState) {
        switch state {
        case .paired:
            connected = true
            pairing = false
            if let pending {
                remoteManager.send(KeyPress(pending.key))
                complete(.success(()))
            }
        case .error(let error):
            connected = false
            guard pending != nil else { return }
            if pairing { return }
            if let activeHost {
                pairing = true
                pairedHosts.remove(activeHost)
                UserDefaults.standard.set(Array(pairedHosts), forKey: "androidTVPairedHosts.v1")
                pairingManager.connect(activeHost, "Hearth Remote", "iPhone")
            } else {
                complete(.failure(RemoteServiceError.protocolError(error.localizedDescription)))
            }
        default: break
        }
    }

    private func handlePairingState(_ state: PairingManager.PairingState) {
        switch state {
        case .waitingCode:
            if let activeHost { DispatchQueue.main.async { self.pairingCodeRequested?(activeHost) } }
        case .successPaired:
            pairing = false
            if let activeHost {
                pairedHosts.insert(activeHost)
                UserDefaults.standard.set(Array(pairedHosts), forKey: "androidTVPairedHosts.v1")
                remoteManager.connect(activeHost)
            }
        case .error(let error):
            pairing = false
            complete(.failure(RemoteServiceError.protocolError(error.localizedDescription)))
        default: break
        }
    }

    private func complete(_ result: Swift.Result<Void, Error>) {
        guard let pending else { return }
        self.pending = nil
        pending.completion(result)
    }
}
