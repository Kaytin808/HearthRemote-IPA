import SwiftUI

struct RemoteView: View {
    @EnvironmentObject private var model: RemoteViewModel
    let device: RemoteDevice

    var body: some View {
        GeometryReader { geometry in
            let compactLayout = geometry.size.height < 740
            let dPadSize = min(
                geometry.size.width - 48,
                compactLayout ? 282 : 312
            )

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    header
                    Spacer(minLength: compactLayout ? 14 : 20)
                    utilityRow
                    Spacer(minLength: compactLayout ? 16 : 24)
                    DirectionPad(size: dPadSize)
                    Spacer(minLength: compactLayout ? 16 : 24)
                    lowerControls
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 20)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 13).fill(.cyan.opacity(0.12))
                Image(systemName: device.kind.symbol).foregroundStyle(.cyan)
            }
            .frame(width: 46, height: 46)

            VStack(alignment: .leading, spacing: 3) {
                Text(device.name).font(.headline).lineLimit(1)
                HStack(spacing: 5) {
                    Circle().fill(.green).frame(width: 6, height: 6)
                    Text(device.kind.rawValue).font(.caption).foregroundStyle(.secondary)
                }
            }
            Spacer()
            Button { model.showingDevices = true } label: {
                Image(systemName: "rectangle.2.swap")
                    .font(.system(size: 18, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .background(.white.opacity(0.07), in: Circle())
            }
            .accessibilityLabel("Change device")
        }
    }

    private var utilityRow: some View {
        HStack {
            RemoteButton(action: .power, symbol: "power", tint: .red)
            Spacer()
            RemoteButton(action: .back, symbol: "chevron.backward")
            Spacer()
            RemoteButton(action: .home, symbol: "house.fill")
            Spacer()
            RemoteButton(action: .options, symbol: "ellipsis")
        }
    }

    private var lowerControls: some View {
        HStack(alignment: .center, spacing: 16) {
            VStack(spacing: 12) {
                VolumeRemoteButton(action: .volumeUp, symbol: "plus", label: "Volume up")
                VolumeRemoteButton(action: .volumeDown, symbol: "minus", label: "Volume down")
            }

            VStack(spacing: 14) {
                HStack(spacing: 14) {
                    RemoteButton(action: .rewind, symbol: "backward.fill", compact: true)
                    RemoteButton(action: .playPause, symbol: "playpause.fill", tint: .cyan, compact: true)
                    RemoteButton(action: .fastForward, symbol: "forward.fill", compact: true)
                }
                HStack(spacing: 14) {
                    RemoteButton(action: .replay, symbol: "gobackward", compact: true)
                    RemoteButton(action: .mute, symbol: "speaker.slash.fill", compact: true)
                }
            }
            .frame(maxWidth: .infinity)
        }
    }
}

private struct DirectionPad: View {
    @EnvironmentObject private var model: RemoteViewModel
    let size: CGFloat

    var body: some View {
        ZStack {
            Circle()
                .fill(.white.opacity(0.055))
                .overlay { Circle().stroke(.white.opacity(0.07), lineWidth: 1) }
                .shadow(color: .black.opacity(0.35), radius: 22, y: 12)

            DPadButton(action: .up, symbol: "chevron.up").offset(y: -size * 0.34)
            DPadButton(action: .down, symbol: "chevron.down").offset(y: size * 0.34)
            DPadButton(action: .left, symbol: "chevron.left").offset(x: -size * 0.34)
            DPadButton(action: .right, symbol: "chevron.right").offset(x: size * 0.34)

            Button { model.send(.select) } label: {
                Circle()
                    .fill(.cyan.gradient)
                    .frame(width: size * 0.36, height: size * 0.36)
                    .overlay { Text("OK").font(.headline).foregroundStyle(.black) }
                    .shadow(color: .cyan.opacity(0.22), radius: 18)
            }
            .buttonStyle(RemotePressStyle())
            .accessibilityLabel("Select")
        }
        .frame(width: size, height: size)
    }
}

private struct DPadButton: View {
    @EnvironmentObject private var model: RemoteViewModel
    let action: RemoteAction
    let symbol: String

    var body: some View {
        Button { model.send(action) } label: {
            Image(systemName: symbol)
                .font(.system(size: 23, weight: .bold))
                .frame(width: 62, height: 62)
                .contentShape(Circle())
        }
        .buttonStyle(RemotePressStyle())
        .accessibilityLabel(action.rawValue)
    }
}

private struct RemoteButton: View {
    @EnvironmentObject private var model: RemoteViewModel
    let action: RemoteAction
    let symbol: String
    var tint: Color = .white
    var compact = false

    var body: some View {
        Button { model.send(action) } label: {
            Image(systemName: symbol)
                .font(.system(size: compact ? 17 : 19, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: compact ? 52 : 56, height: compact ? 52 : 56)
                .background(.white.opacity(0.075), in: Circle())
                .overlay { Circle().stroke(.white.opacity(0.055), lineWidth: 1) }
        }
        .buttonStyle(RemotePressStyle())
        .accessibilityLabel(action.rawValue)
    }
}

private struct VolumeRemoteButton: View {
    @EnvironmentObject private var model: RemoteViewModel
    let action: RemoteAction
    let symbol: String
    let label: String

    var body: some View {
        Button { model.send(action) } label: {
            HStack(spacing: 10) {
                Image(systemName: "speaker.wave.2.fill")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.secondary)
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .bold))
            }
            .frame(width: 106, height: 58)
            .background(
                .white.opacity(0.075),
                in: RoundedRectangle(cornerRadius: 19, style: .continuous)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 19, style: .continuous)
                    .stroke(.white.opacity(0.065), lineWidth: 1)
            }
            .contentShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
        }
        .buttonStyle(RemotePressStyle())
        .accessibilityLabel(label)
    }
}

private struct RemotePressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.72 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}
