import SwiftUI

struct RootView: View {
    @EnvironmentObject private var model: RemoteViewModel

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.035, green: 0.055, blue: 0.075), Color(red: 0.07, green: 0.09, blue: 0.11)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            if let device = model.selectedDevice {
                RemoteView(device: device)
            } else {
                EmptyRemoteView()
            }
        }
        .sheet(isPresented: $model.showingDevices) {
            DevicePickerView()
                .environmentObject(model)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: Binding(
            get: { model.pairingHost != nil },
            set: { if !$0, model.pairingHost != nil { model.cancelPairing() } }
        )) {
            PairingCodeView()
                .environmentObject(model)
                .interactiveDismissDisabled()
        }
        .overlay(alignment: .bottom) {
            if let notice = model.notice {
                NoticeView(notice: notice)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 10)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .task(id: notice.id) {
                        try? await Task.sleep(for: .seconds(notice.style == .error ? 5 : 3))
                        if model.notice?.id == notice.id {
                            withAnimation { model.notice = nil }
                        }
                    }
            }
        }
        .animation(.spring(response: 0.35), value: model.notice)
        .onAppear {
            if model.allDevices.isEmpty { model.scan() }
        }
    }
}

private struct PairingCodeView: View {
    @EnvironmentObject private var model: RemoteViewModel
    @State private var code = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                ZStack {
                    Circle().fill(.cyan.opacity(0.12)).frame(width: 94, height: 94)
                    Image(systemName: "tv.and.mediabox").font(.system(size: 38)).foregroundStyle(.cyan)
                }
                VStack(spacing: 7) {
                    Text("Pair with your TV").font(.title2.bold())
                    Text("Enter the six-character code shown on the TV screen.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                TextField("A1B2C3", text: $code)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .font(.system(size: 30, weight: .bold, design: .monospaced))
                    .multilineTextAlignment(.center)
                    .padding()
                    .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
                    .onChange(of: code) { value in
                        code = String(value.uppercased().filter { "0123456789ABCDEF".contains($0) }.prefix(6))
                    }
                Button {
                    model.submitPairingCode(code)
                } label: {
                    Text("Pair device")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(.cyan, in: Capsule())
                        .foregroundStyle(.black)
                }
                .disabled(code.count != 6)
                Spacer()
            }
            .padding(28)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { model.cancelPairing() }
                }
            }
        }
    }
}

private struct EmptyRemoteView: View {
    @EnvironmentObject private var model: RemoteViewModel

    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            ZStack {
                Circle().fill(.cyan.opacity(0.1)).frame(width: 116, height: 116)
                Image(systemName: "dot.radiowaves.left.and.right")
                    .font(.system(size: 45, weight: .medium))
                    .foregroundStyle(.cyan)
            }
            VStack(spacing: 8) {
                Text("Your couch command center")
                    .font(.title2.bold())
                Text("Connect a TV or streaming player on this Wi-Fi network.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 38)
            }
            Button {
                model.showingDevices = true
            } label: {
                Label("Choose a device", systemImage: "plus")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(.cyan, in: Capsule())
                    .foregroundStyle(.black)
            }
            .padding(.horizontal, 34)
            Spacer()
            Text("Local only · No account · No subscription")
                .font(.caption)
                .foregroundStyle(.tertiary)
                .padding(.bottom, 22)
        }
    }
}

private struct NoticeView: View {
    let notice: RemoteViewModel.Notice

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: notice.style == .error ? "exclamationmark.triangle.fill" : "wave.3.right")
                .foregroundStyle(notice.style == .error ? .orange : .cyan)
            Text(notice.text).font(.subheadline.weight(.medium))
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.08))
        }
    }
}
