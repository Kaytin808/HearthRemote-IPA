import SwiftUI

struct DevicePickerView: View {
    @EnvironmentObject private var model: RemoteViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var showingManual = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button { model.scan() } label: {
                        HStack {
                            Label(model.isDiscovering ? "Scanning…" : "Scan home network", systemImage: "dot.radiowaves.left.and.right")
                            Spacer()
                            if model.isDiscovering { ProgressView() }
                        }
                    }
                    .disabled(model.isDiscovering)

                    Button { showingManual = true } label: {
                        Label("Add manually", systemImage: "plus.circle")
                    }
                }

                if model.allDevices.isEmpty && !model.isDiscovering {
                    VStack(spacing: 10) {
                        Image(systemName: "wifi.slash").font(.title2).foregroundStyle(.secondary)
                        Text("No devices yet").font(.headline)
                        Text("Make sure the iPhone and TV are on the same Wi-Fi, or add the TV's IP address.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 24)
                } else {
                    Section("Devices") {
                        ForEach(model.allDevices) { device in
                            Button { model.select(device) } label: {
                                DeviceRow(device: device, selected: model.selectedDevice?.id == device.id)
                            }
                            .buttonStyle(.plain)
                            .swipeActions {
                                if model.savedDevices.contains(where: { $0.id == device.id }) {
                                    Button(role: .destructive) { model.remove(device) } label: {
                                        Label("Forget", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                }

                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Android & Fire TV setup", systemImage: "wrench.and.screwdriver")
                            .font(.subheadline.weight(.semibold))
                        Text("Google TV, Onn, and Shield pair with the code shown on the TV. Fire TV uses ADB: enable ADB debugging, then use port 5555 and accept its authorization prompt.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Devices")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .sheet(isPresented: $showingManual) {
                ManualDeviceView()
                    .environmentObject(model)
            }
        }
    }
}

private struct DeviceRow: View {
    let device: RemoteDevice
    let selected: Bool

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: device.kind.symbol)
                .font(.system(size: 18))
                .foregroundStyle(.cyan)
                .frame(width: 38, height: 38)
                .background(.cyan.opacity(0.1), in: RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 3) {
                Text(device.name).font(.body.weight(.medium))
                Text("\(device.host):\(device.port)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if device.discovered { Text("Nearby").font(.caption2).foregroundStyle(.secondary) }
            if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(.cyan) }
        }
        .contentShape(Rectangle())
    }
}

private struct ManualDeviceView: View {
    @EnvironmentObject private var model: RemoteViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var host = ""
    @State private var kind: DeviceKind = .shield
    @State private var port = "6466"

    var body: some View {
        NavigationStack {
            Form {
                Section("Device") {
                    Picker("Type", selection: $kind) {
                        ForEach(DeviceKind.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    .onChange(of: kind) { newKind in
                        port = newKind == .roku ? "8060" : (newKind == .fireTV ? "5555" : "6466")
                    }
                    TextField("Name (optional)", text: $name)
                    TextField("IP address", text: $host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.numbersAndPunctuation)
                    TextField("Port", text: $port)
                        .keyboardType(.numberPad)
                }

                Section {
                    Text(kind == .roku
                         ? "Roku normally uses port 8060 and must allow Control by mobile apps."
                         : (kind == .fireTV
                            ? "Fire TV uses ADB on port 5555. Enable ADB debugging before connecting."
                            : "Android TV Remote Service uses port 6466 and pairs with a six-character code—no Developer Options required."))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Add device")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        guard let numericPort = UInt16(port) else { return }
                        model.add(.manual(name: name, host: host, kind: kind, port: numericPort))
                        dismiss()
                    }
                    .disabled(host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || UInt16(port) == nil)
                }
            }
        }
    }
}
