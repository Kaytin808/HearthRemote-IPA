import Foundation

enum RemoteAction: String, CaseIterable, Identifiable {
    case power, home, back, up, down, left, right, select
    case volumeUp, volumeDown, mute
    case playPause, rewind, fastForward
    case options, replay

    var id: String { rawValue }

    var rokuKey: String {
        switch self {
        case .power: return "Power"
        case .home: return "Home"
        case .back: return "Back"
        case .up: return "Up"
        case .down: return "Down"
        case .left: return "Left"
        case .right: return "Right"
        case .select: return "Select"
        case .volumeUp: return "VolumeUp"
        case .volumeDown: return "VolumeDown"
        case .mute: return "VolumeMute"
        case .playPause: return "Play"
        case .rewind: return "Rev"
        case .fastForward: return "Fwd"
        case .options: return "Info"
        case .replay: return "InstantReplay"
        }
    }

    var androidKeyCode: Int {
        switch self {
        case .power: return 26
        case .home: return 3
        case .back: return 4
        case .up: return 19
        case .down: return 20
        case .left: return 21
        case .right: return 22
        case .select: return 23
        case .volumeUp: return 24
        case .volumeDown: return 25
        case .mute: return 164
        case .playPause: return 85
        case .rewind: return 89
        case .fastForward: return 90
        case .options: return 82
        case .replay: return 87
        }
    }
}

