import Foundation

enum DeviceTransport: String, Codable, CaseIterable {
    case roku
    case androidRemote
    case adb
}

enum DeviceKind: String, Codable, CaseIterable {
    case roku = "Roku"
    case shield = "NVIDIA Shield"
    case googleTV = "Google / Onn TV"
    case fireTV = "Fire TV"
    case androidTV = "Android TV"

    var symbol: String {
        switch self {
        case .roku: return "tv"
        case .shield: return "gamecontroller.fill"
        case .googleTV: return "play.tv.fill"
        case .fireTV: return "flame.fill"
        case .androidTV: return "display"
        }
    }
}

struct RemoteDevice: Identifiable, Codable, Hashable {
    var name: String
    var host: String
    var port: UInt16
    var kind: DeviceKind
    var transport: DeviceTransport
    var discovered: Bool = false

    var id: String { "\(transport.rawValue)|\(host.lowercased())|\(port)" }

    static func manual(name: String, host: String, kind: DeviceKind, port: UInt16) -> Self {
        .init(
            name: name.isEmpty ? kind.rawValue : name,
            host: host.trimmingCharacters(in: .whitespacesAndNewlines),
            port: port,
            kind: kind,
            transport: kind == .roku ? .roku : (kind == .fireTV ? .adb : .androidRemote)
        )
    }
}
